import { TurmaDto } from './turma.dto';

describe('TurmaDto', () => {
  it('should be defined', () => {
    expect(new TurmaDto()).toBeDefined();
  });
});
