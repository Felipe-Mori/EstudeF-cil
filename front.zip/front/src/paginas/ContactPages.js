import React from "react";

function ContactPages() {
    return (
        <div>
            <h2>Contato</h2>
            <p>Aqui você pode encontrar maneiras de entrar em contato conosco.</p>
        </div>
    );
}

export default ContactPages;