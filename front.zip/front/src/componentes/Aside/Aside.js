import React from "react";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import { Link } from "react-router-dom";
import menuLinks from "../../jsondata/menulinks.json";

function Aside() {
    return (
        <div>
            
        </div>
    );
}

export default Aside;