import React from "react";

function Footer() {
    return (
        <footer>
            <p>Direitos não reservados😎 © Estudefácil 2024.</p>
        </footer>
    );
}

export default Footer;